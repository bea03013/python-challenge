# PyPoll
# Michelle Goodman


import os
import csv

# set a csv file path to get the data
poll_csv = os.path.join('Resources', 'election_data.csv')

# define function
def pypoll(data):

    # define variables/lists
    totalCountVotes = 0
    votes = []
    candidateCount = []
    uniqueCandidates = []
    percent = []
     
    # start looping through rows
    for row in data:

        # count the total number of votes
        totalCountVotes += 1

        # append unique names to the candidates list
        #Using not it qualifier
        
        if row[2] not in uniqueCandidates:
            uniqueCandidates.append(row[2])

        # make a list of all the votes
        votes.append(row[2])

    # start a second loop that will populate the candidateCount with each vote
    for candidate in uniqueCandidates:
        candidateCount.append(votes.count(candidate))
        percent.append(round(votes.count(candidate)/totalCountVotes*100,3))

    # find the winner using index of max count in candidateCount
    winner = uniqueCandidates[candidateCount.index(max(candidateCount))]
    
    # print results
    print('Election Results')
    print('--------------------------')
    print(f'Total Votes: {totalCountVotes}')
    print('--------------------------')
    for i in range(len(uniqueCandidates)):
        print(f'{uniqueCandidates[i]}: {percent[i]}% {candidateCount[i]}')
    print('--------------------------')
    print(f'Winner: {winner}')
    print('--------------------------')

    # set path for text file
    poll_output = os.path.join("PyPollResults.txt")

    # write out results to text file
    with open(poll_output, "w") as txtfile:
        txtfile.write('Election Results\n')
        txtfile.write('------------------------------\n')
        txtfile.write(f'Total Votes: {totalCountVotes}\n')
        txtfile.write('------------------------------\n')
        for i in range (len(uniqueCandidates)):
            txtfile.write(f'{uniqueCandidates[i]}: {percent[i]}% {candidateCount[i]}\n')
        txtfile.write('------------------------------\n')
        txtfile.write(f'Winner: {winner}\n')
        txtfile.write('------------------------------')


# read in the CSV file
with open(poll_csv, newline='') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')

    # adjust for header
    csv_header = next(csvfile)
    
    # use function
    pypoll(csvreader)
