# PyBank
# Michelle Goodman

import os
import csv

# CSV file path to get data
bank_csv = os.path.join('Resources', 'budget_data.csv')

# make a function
def analyze_bank(data):

    # define variables and Lists
    monthCount = 0
    netProfit = 0
    monthProfit = 0
    change = 0
    monthList = []
    changeList = []
    
    # loop through rows
    for row in data:
       
        # increase monthCount for each row
        monthCount += 1
        
        # increase netprofit with each row
        netProfit += int(row[1])
        
        # add each month to monthList
        monthList.append(str(row[0]))
        
        # Calculate changes in profit for each month
        
        # if there is previous data (Most of the rows):
        if change != 0:
            
            # set monthProfit to value in profit column
            monthProfit = int(row[1])
            
            # subtract current profit from previous month's profits to find change
            change = monthProfit - change
            
            # Store it in the changeList
            changeList.append(change)
            
            # reset change variable to the value in the current profit column so it's ready to start the next row
            change = int(row[1])
            
        # if there is no previous data...so the first row
        elif change == 0:
            change = int(row[1])  
            
    # take away 1st month from monthList since there is no change
    monthList.pop(0)
    
    # find the index position of the greatest increase in profits from my changeList
    indxmax = changeList.index(max(changeList))

    # find the index position of the greatest decrease in profits from my changeList
    indxmin = changeList.index(min(changeList))

    # use index positions to find the month that corresponds with max and min values from the changeList
    maxChange = (f'{monthList[int(indxmax)]} (${max(changeList)})')
    minChange = (f'{monthList[int(indxmin)]} (${min(changeList)})')
    
    # take average of the changeList
    average = sum(changeList)/float(len(changeList))
    average = round(average,2)
    
    # print the results
    print(f'Financial Analysis')
    print(f'---------------------------')
    print('')
    print(f'Total Months: {monthCount}')
    print('')
    print(f'Total: ${netProfit}')
    print('')
    print(f'Average Change: ${average}')
    print('')
    print(f'Greatest Increase in Profits: {maxChange}')
    print('')
    print(f'Greatest Decrease In Profits: {minChange}')

    # set the file to write to
    bank_output = os.path.join("PyBankResults.txt")    
    
    # write the results to a text file
    with open(bank_output, 'w') as txtfile:
        txtfile.write('Financial Analysis\n')
        txtfile.write('------------------------\n\n')
        txtfile.write(f'Total Months: {monthCount}\n\n')
        txtfile.write(f'Total: ${netProfit}\n\n')
        txtfile.write(f'Average Change: ${average}\n\n')
        txtfile.write(f'Greatest Increase In Profits: {maxChange}\n\n')
        txtfile.write(f'Greatest Decrease In Profits: {minChange}')

# read in the CSV file
with open(bank_csv, 'r', newline='') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')

    # adjust for header
    csv_header = next(csvfile)
    
    # use function
    analyze_bank(csvreader)
